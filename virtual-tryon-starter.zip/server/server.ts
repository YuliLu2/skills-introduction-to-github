
import express from 'express';
import dotenv from 'dotenv';
import fetch from 'node-fetch';
import bodyParser from 'body-parser';

dotenv.config();
const app = express();
const PORT = 3000;

app.use(bodyParser.json({ limit: '10mb' }));

app.post('/generate', async (req, res) => {
  const { userImage, productData } = req.body;
  const prompt = `A woman wearing a ${productData.title}, made of ${productData.fabric || 'cloth'}, realistic lighting, full body.`;

  const response = await fetch('https://api.replicate.com/v1/predictions', {
    method: 'POST',
    headers: {
      'Authorization': `Token ${process.env.REPLICATE_API_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      version: "cf2e206f7eafd36c478647fb4f43f4afef22e3d7900c7a7b2ec30ce0f7b1e05b", // Imagen 3 model version
      input: { prompt }
    })
  });

  const data = await response.json();
  res.json(data);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
